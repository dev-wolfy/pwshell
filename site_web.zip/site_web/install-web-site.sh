#!/bin/bash

apt install apache2 apache2-utils

unzip -q /srv/laboiia.zip -d /var/www

chown -R www-data:www-data /var/www/laboiia


cat > /etc/apache2/sites-available/001-laboiia.conf <<EOF
<VirtualHost *:80>
        ServerName www.laboiia.fr

        ServerAdmin webmaster@localhost
        DocumentRoot /var/www/laboiia

        ErrorLog ${APACHE_LOG_DIR}/error.log
        CustomLog ${APACHE_LOG_DIR}/access.log combined

</VirtualHost>
EOF

/usr/sbin/a2ensite 001-laboiia.conf

systemctl restart apache2


